/**
  * Copyright 2021 json.cn 
  */
package com.swallowincense.product.vo;

/**
 * Auto-generated: 2021-08-02 20:52:53
 *
 * @author json.cn (i@json.cn)
 * @website http://www.json.cn/java2pojo/
 */
public class Bounds {

    private int buyBounds;
    private int growBounds;
    public void setBuyBounds(int buyBounds) {
         this.buyBounds = buyBounds;
     }
     public int getBuyBounds() {
         return buyBounds;
     }

    public void setGrowBounds(int growBounds) {
         this.growBounds = growBounds;
     }
     public int getGrowBounds() {
         return growBounds;
     }

}