/**
  * Copyright 2021 json.cn 
  */
package com.swallowincense.product.vo;

/**
 * Auto-generated: 2021-08-02 20:52:53
 *
 * @author json.cn (i@json.cn)
 * @website http://www.json.cn/java2pojo/
 */
public class BaseAttrs {

    private int attrId;
    private String attrValues;
    private int showDesc;
    public void setAttrId(int attrId) {
         this.attrId = attrId;
     }
     public int getAttrId() {
         return attrId;
     }

    public void setAttrValues(String attrValues) {
         this.attrValues = attrValues;
     }
     public String getAttrValues() {
         return attrValues;
     }

    public void setShowDesc(int showDesc) {
         this.showDesc = showDesc;
     }
     public int getShowDesc() {
         return showDesc;
     }

}